package com.example;

public class Actionwords {

    public void typingCorrectURLToTheBrowser(String uRL) {

    }

    public void userLoggedIn() {

    }

    public void showTheSauceDemoHomePage() {

    }

    public void userClickLoginButton() {

    }

    public void userInputValidPassword(String freeText, DataTable datatable) {

    }

    public void userInputValidUsername(DataTable datatable, String freeText) {

    }

    public void userInputNOTValidPassword(String freeText, DataTable datatable) {

    }

    public void userCANTLogin() {

    }

    public void userClickAProductItem() {

    }

    public void numberInCartsIconIncrease() {

    }

    public void userAddAProductToTheCart() {

    }

    public void userClickCartsIcon() {

    }

    public void userClickCheckoutButton() {

    }

    public void showCheckoutRespondMessages() {

    }

    public void showPageYourInformationPage() {

    }

    public void inputFirstNameText(String freeText, DataTable datatable) {

    }

    public void inputLastNameText(String freeText, DataTable datatable) {

    }

    public void inputZippostalCode(String freeText, DataTable datatable) {

    }

    public void clickContinueButton() {

    }

    public void showPageCheckoutOverview() {

    }

    public void clickFinishButton() {

    }
}